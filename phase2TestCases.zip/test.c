int test(int a, int b)
{
  int c = a + b;
  int d = b + c;
  int e = a + b;
  int f = b + e;
  
  return f;
}
