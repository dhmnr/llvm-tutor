void test1(int a, int b, int c, int d, int e, int f, int g) {
    c = a + b;
    d = c + 5;
    e = a + b;
    f = e + 5;
    g = d + f;
}
