void test2(int a, int b, int c, int x, int y) {
    b = x + y;
    a = x + y;
    a = 17;
    c = x + y;
}
