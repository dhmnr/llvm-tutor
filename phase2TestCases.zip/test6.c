void test6(int c, int d, int e, int i, int j)
{
    int a = 10;
    int b = 40;
    int t1 = i * j;
    c = t1 + 40;
    int t2 = 150;
    d = 150 * c;
    e = i;
    int t3 = i * j;
    int t4 = i * 10;
    c = t1 + t4;   
}
